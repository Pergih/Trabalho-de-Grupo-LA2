int Conjunto(wchar_t *s);
int Sequencia(wchar_t *s);
int DSequencia (wchar_t *s);