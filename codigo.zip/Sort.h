void sortCartas (wchar_t *s, size_t n);
int compare(const void *a, const void *b);
void find_indices(wchar_t m[], int N, short int v[]);