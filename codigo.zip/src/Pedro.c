#include <stdio.h>

void pedro () {
    printf ("pepega\n");
}