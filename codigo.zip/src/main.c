#include <stdio.h>
#include "Pedro.h"

int main () {
    printf ("main\n");
    pedro ();
}