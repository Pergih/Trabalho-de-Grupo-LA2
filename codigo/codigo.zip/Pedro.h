void sortCartas (wchar_t *s, size_t n);
int DSequencia (wchar_t *s);